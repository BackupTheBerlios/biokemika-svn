//@line 36 "e:\builds\moz2_slave\win32_repack\build\releases\l10n-mozilla-1.9.2\de\browser\firefox-l10n.js"

//@line 38 "e:\builds\moz2_slave\win32_repack\build\releases\l10n-mozilla-1.9.2\de\browser\firefox-l10n.js"

pref("general.useragent.locale", "de");
