pref("general.useragent.extra.microsoftdotnet", ""); // http://www.mozilla.org/build/revised-user-agent-strings.html#implementation
pref("microsoft.CLR.clickonce.autolaunch", true);
pref("microsoft.CLR.all_clr_versions_in_useragent", false);
pref("microsoft.CLR.auto_install", true);
pref("extensions.{20a82645-c095-46ed-80e3-08825760534b}.description", "chrome://dotnetassistant/locale/dotnetassistant.properties");

